Welcome to the libtcod 1.5.1 OSX release. 

To both develop and run applications linked against libtcod, you will need to install the following frameworks. 

Download the following frameworks:
http://www.libsdl.org/release/SDL-1.2.14.dmgi
http://ethan.tira-thompson.org/Mac_OS_X_Ports_files/libpng%20%28universal%29.dmg

Mount the .dmg and copy the framework to /Libraries/Frameworks (you might need to run finder as root. If so, in terminal "paste sudo /System/Library/CoreServices/Finder.app/Contents/MacOS/Finder")

You can run the pre-compiled binaries provided. In addition, an xcode project is provided in the xcode directory. Do note, that only the i386 build will work, as that is the only version of libtcod provided for this release.

Questions? Problems? Contact chris.hamons@gmail.com
